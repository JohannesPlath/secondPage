

function addStuff(){
    var famNameS = document.forms["LogIn3"]["famNameS"].value;
    var First_Name = document.forms["addStuff"]["First_Name"].value;
    var Last_Name = document.forms["addStuff"]["Last_Name"].value;
    var DOB = document.forms["addStuff"]["DOB"].value;
    var Department = document.forms["addStuff"]["Department"].value;
    var Mail = document.forms["addStuff"]["Mail"].value;

    if (true)
        return true

}